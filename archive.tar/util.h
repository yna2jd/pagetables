//
// Created by sebastian-f on 3/1/24.
//

#ifndef CSO2_UTIL_H
#define CSO2_UTIL_H
#include <stdio.h>
void printBits(char const* label, size_t const * const ptr);
void putBits(size_t const* const ptr);
#endif //CSO2_UTIL_H
