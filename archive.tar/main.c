//
// Created by sebastian-f on 3/21/24.
//
#include "test.h"
int main(){
    test(0);
    test(1);
}